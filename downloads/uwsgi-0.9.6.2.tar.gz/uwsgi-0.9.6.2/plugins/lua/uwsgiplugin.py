import os,sys

NAME='lua'
CFLAGS = '-I /usr/include/lua5.1'
LDFLAGS = '-llua5.1'
