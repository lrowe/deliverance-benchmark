NAME='example'
CFLAGS = ''
LDFLAGS = ''
